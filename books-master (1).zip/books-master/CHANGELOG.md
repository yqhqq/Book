# Changelog
# Title
### Description by [Liyas Thomas](https://github.com/liyasthomas)

---

# 1.0.0

## This is it, Title 1.0.0!
We are finally out of beta, therefore many bugs were fixed and camera received a brand new look.

* **NEW**: Camera redesign
* **NEW**: Camera redesign
* **NEW**: macOS and iOS support
* **IMPROVEMENT**: Major improvements
* **IMPROVEMENT**: Updated libraries
* **FIX**: Fixed many bugs and crashes
* **FIX**: Graphic glitches
* **FIX**: Statusbar too dark
* **TRANSLATION**: Updated translations
* **REVERT**: Brought back the "Help" button
* **OTHER**: Removed all analytics

---

# 0.9.0

## I worked a lot on Web apps, WebAR, WebGL & PWAs
So I think Lvr is now ready to be released :)

I will keep the usual branch model.

* Stable release on `master` branch

---

## Thanks
* [Google](https://www.google.com) - for [Polymer](https://polymer-project.org)
